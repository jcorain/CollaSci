from setuptools import setup

setup()
# import pathlib

# here = pathlib.Path(__file__).parent.resolve()

# # Get the long description from the README file
# long_description = (here / "README.md").read_text(encoding="utf-8")

# setup(
#       name = "CollaSci",
#       version = "0.0.1",
#       description = "A package aimed to share scientific data",
#       author ="Jean-Christophe Orain", 
#       author_email="jean.christophe.orain@gmail.com",
#       classifiers = [
#           "Programming Language :: Python :: 3",
#           "License :: OSI Approved :: MIT License",
#           "Operating System :: OS Independent",
#           ],
#       license = 'MIT',
#       python_requires = '>=3.9',
#       # install_requires = []
#       )

