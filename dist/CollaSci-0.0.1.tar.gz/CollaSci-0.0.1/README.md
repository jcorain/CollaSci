# CollaSci 

##Purpose

CollaSci is a python package aimed to develop scientific collaboration via database management and easy visualization.
At first, the database is based on condensed matter data related to magnetism and developing user interface to easily add and share data. 

## Bug reporting 

To report a bug, please use the gitlab page for the package for the sake of documentation. You can open a new issue on this page and we will try to tackle it down.

## Contribution

Any contribution is most welcomed. Feel free to contact the maintainer of the package for any added value.